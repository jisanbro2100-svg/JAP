package com.jap.app

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import android.app.Activity

data class DataPoint(val serial:Int, val type:String, val number:Int)

class MainActivity : Activity() {
    private val data = listOf(
        DataPoint(1, "B", 5),
        DataPoint(2, "B", 7),
        DataPoint(3, "S", 3),
        DataPoint(4, "S", 0),
        DataPoint(5, "S", 1),
        DataPoint(6, "B", 8),
        DataPoint(7, "S", 3),
        DataPoint(8, "B", 6),
        DataPoint(9, "S", 4),
        DataPoint(10, "S", 2),
        DataPoint(11, "S", 4),
        DataPoint(12, "B", 7),
        DataPoint(13, "B", 7),
        DataPoint(14, "S", 1),
        DataPoint(15, "B", 8),
        DataPoint(16, "B", 6),
        DataPoint(17, "B", 7),
        DataPoint(18, "S", 0),
        DataPoint(19, "S", 3),
        DataPoint(20, "B", 8),
        DataPoint(21, "B", 6),
        DataPoint(22, "S", 2),
        DataPoint(23, "S", 0),
        DataPoint(24, "B", 7),
        DataPoint(25, "S", 4),
        DataPoint(26, "S", 4),
        DataPoint(27, "S", 2),
        DataPoint(28, "S", 2),
        DataPoint(29, "B", 7),
        DataPoint(30, "B", 5),
        DataPoint(31, "S", 3),
        DataPoint(32, "B", 6),
        DataPoint(33, "B", 8),
        DataPoint(34, "S", 0),
        DataPoint(35, "S", 2),
        DataPoint(36, "B", 7),
        DataPoint(37, "B", 5),
        DataPoint(38, "S", 4),
        DataPoint(39, "S", 0),
        DataPoint(40, "B", 5),
        DataPoint(41, "S", 2),
        DataPoint(42, "B", 6),
        DataPoint(43, "S", 2),
        DataPoint(44, "S", 3),
        DataPoint(45, "B", 5),
        DataPoint(46, "B", 6),
        DataPoint(47, "S", 0),
        DataPoint(48, "S", 1),
        DataPoint(49, "B", 5),
        DataPoint(50, "S", 3),
        DataPoint(51, "B", 5),
        DataPoint(52, "S", 0),
        DataPoint(53, "S", 0),
        DataPoint(54, "S", 1),
        DataPoint(55, "B", 7),
        DataPoint(56, "B", 8),
        DataPoint(57, "B", 5),
        DataPoint(58, "S", 4),
        DataPoint(59, "S", 0),
        DataPoint(60, "B", 8),
        DataPoint(61, "S", 0),
        DataPoint(62, "B", 8),
        DataPoint(63, "B", 9),
        DataPoint(64, "S", 0),
        DataPoint(65, "B", 9),
        DataPoint(66, "S", 2),
        DataPoint(67, "B", 5),
        DataPoint(68, "S", 2),
        DataPoint(69, "B", 8),
        DataPoint(70, "B", 7),
        DataPoint(71, "S", 4),
        DataPoint(72, "S", 4),
        DataPoint(73, "S", 1),
        DataPoint(74, "S", 4),
        DataPoint(75, "S", 1),
        DataPoint(76, "S", 3),
        DataPoint(77, "B", 7),
        DataPoint(78, "B", 5),
        DataPoint(79, "S", 3),
        DataPoint(80, "B", 8),
        DataPoint(81, "S", 0),
        DataPoint(82, "B", 5),
        DataPoint(83, "B", 9),
        DataPoint(84, "B", 7),
        DataPoint(85, "B", 6),
        DataPoint(86, "S", 2),
        DataPoint(87, "B", 5),
        DataPoint(88, "S", 1),
        DataPoint(89, "S", 2),
        DataPoint(90, "S", 1),
        DataPoint(91, "S", 4),
        DataPoint(92, "B", 6),
        DataPoint(93, "S", 4),
        DataPoint(94, "S", 4),
        DataPoint(95, "B", 5),
        DataPoint(96, "S", 0),
        DataPoint(97, "S", 1),
        DataPoint(98, "S", 0),
        DataPoint(99, "B", 7),
        DataPoint(100, "B", 6),
        DataPoint(101, "S", 2),
        DataPoint(102, "S", 1),
        DataPoint(103, "B", 9),
        DataPoint(104, "B", 7),
        DataPoint(105, "S", 3),
        DataPoint(106, "B", 9),
        DataPoint(107, "B", 9),
        DataPoint(108, "B", 7),
        DataPoint(109, "S", 3),
        DataPoint(110, "S", 4),
        DataPoint(111, "B", 7),
        DataPoint(112, "S", 2),
        DataPoint(113, "S", 0),
        DataPoint(114, "B", 7),
        DataPoint(115, "S", 0),
        DataPoint(116, "B", 7),
        DataPoint(117, "B", 6),
        DataPoint(118, "B", 7),
        DataPoint(119, "S", 2),
        DataPoint(120, "S", 3),
        DataPoint(121, "S", 1),
        DataPoint(122, "B", 6),
        DataPoint(123, "S", 0),
        DataPoint(124, "B", 6),
        DataPoint(125, "S", 4),
        DataPoint(126, "S", 3),
        DataPoint(127, "B", 5),
        DataPoint(128, "S", 3),
        DataPoint(129, "B", 9),
        DataPoint(130, "B", 6),
        DataPoint(131, "S", 4),
        DataPoint(132, "S", 1),
        DataPoint(133, "B", 8),
        DataPoint(134, "B", 5),
        DataPoint(135, "S", 4),
        DataPoint(136, "B", 9),
        DataPoint(137, "B", 6),
        DataPoint(138, "S", 0),
        DataPoint(139, "B", 9),
        DataPoint(140, "S", 1),
        DataPoint(141, "S", 0),
        DataPoint(142, "S", 0),
        DataPoint(143, "B", 7),
        DataPoint(144, "B", 7),
        DataPoint(145, "B", 5),
        DataPoint(146, "S", 3),
        DataPoint(147, "S", 1),
        DataPoint(148, "S", 1),
        DataPoint(149, "S", 4),
        DataPoint(150, "B", 5),
        DataPoint(151, "S", 2),
        DataPoint(152, "B", 5),
        DataPoint(153, "S", 0),
        DataPoint(154, "B", 9),
        DataPoint(155, "B", 5),
        DataPoint(156, "B", 6),
        DataPoint(157, "B", 8),
        DataPoint(158, "B", 9),
        DataPoint(159, "B", 5),
        DataPoint(160, "B", 9),
        DataPoint(161, "B", 5),
        DataPoint(162, "B", 8),
        DataPoint(163, "B", 8),
        DataPoint(164, "B", 8),
        DataPoint(165, "B", 7),
        DataPoint(166, "B", 5),
        DataPoint(167, "B", 7),
        DataPoint(168, "S", 4),
        DataPoint(169, "S", 4),
        DataPoint(170, "B", 5),
        DataPoint(171, "S", 4),
        DataPoint(172, "B", 9),
        DataPoint(173, "B", 9),
        DataPoint(174, "B", 8),
        DataPoint(175, "B", 9),
        DataPoint(176, "S", 2),
        DataPoint(177, "S", 2),
        DataPoint(178, "B", 6),
        DataPoint(179, "S", 0),
        DataPoint(180, "B", 7),
        DataPoint(181, "S", 3),
        DataPoint(182, "S", 0),
        DataPoint(183, "B", 7),
        DataPoint(184, "B", 7),
        DataPoint(185, "B", 5),
        DataPoint(186, "B", 9),
        DataPoint(187, "S", 2),
        DataPoint(188, "B", 7),
        DataPoint(189, "B", 8),
        DataPoint(190, "S", 4),
        DataPoint(191, "B", 8),
        DataPoint(192, "B", 6),
        DataPoint(193, "S", 3),
        DataPoint(194, "S", 0),
        DataPoint(195, "S", 1),
        DataPoint(196, "B", 6),
        DataPoint(197, "S", 0),
        DataPoint(198, "B", 9),
        DataPoint(199, "S", 1),
        DataPoint(200, "B", 7),
        DataPoint(201, "S", 2),
        DataPoint(202, "S", 4),
        DataPoint(203, "B", 9),
        DataPoint(204, "B", 9),
        DataPoint(205, "B", 7),
        DataPoint(206, "B", 7),
        DataPoint(207, "B", 5),
        DataPoint(208, "S", 1),
        DataPoint(209, "S", 1),
        DataPoint(210, "S", 2),
        DataPoint(211, "B", 8),
        DataPoint(212, "B", 8),
        DataPoint(213, "B", 9),
        DataPoint(214, "B", 8),
        DataPoint(215, "S", 2),
        DataPoint(216, "S", 3),
        DataPoint(217, "S", 0),
        DataPoint(218, "S", 3),
        DataPoint(219, "S", 0),
        DataPoint(220, "B", 6),
        DataPoint(221, "S", 2),
        DataPoint(222, "B", 6),
        DataPoint(223, "B", 7),
        DataPoint(224, "B", 7),
        DataPoint(225, "S", 1),
        DataPoint(226, "S", 3),
        DataPoint(227, "S", 0),
        DataPoint(228, "S", 0),
        DataPoint(229, "S", 4)
    )

    private val bg = Color.rgb(7,7,10)
    private val panel = Color.rgb(18,18,24)
    private val blue = Color.rgb(41,121,255)
    private val red = Color.rgb(220,40,55)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun base(): LinearLayout {
        val root=LinearLayout(this)
        root.orientation=LinearLayout.VERTICAL
        root.setPadding(28,28,28,28)
        root.setBackgroundColor(bg)
        return root
    }

    private fun title(text:String): TextView {
        return TextView(this).apply {
            this.text=text
            textSize=28f
            setTextColor(Color.WHITE)
            gravity=Gravity.CENTER
            setPadding(8,20,8,20)
        }
    }

    private fun showLogin() {
        val root=base()
        root.addView(title("JAP"))
        val sub=TextView(this).apply {
            text="JAP • Pattern Analysis"
            textSize=15f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER
        }
        root.addView(sub, LinearLayout.LayoutParams(-1,60))
        val user=EditText(this).apply {
            hint="Username"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        val pass=EditText(this).apply {
            hint="Password"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(user, LinearLayout.LayoutParams(-1,60).apply{setMargins(0,24,0,10)})
        root.addView(pass, LinearLayout.LayoutParams(-1,60))
        val login=Button(this).apply { text="LOGIN" }
        root.addView(login, LinearLayout.LayoutParams(-1,60).apply{setMargins(0,22,0,0)})
        login.setOnClickListener {
            if(user.text.toString()=="Jisan_Power12" && pass.text.toString()=="JAPMIND@") showHome()
            else Toast.makeText(this,"Invalid username or password",Toast.LENGTH_SHORT).show()
        }
        setContentView(root)
    }

    private fun showHome() {
        val root=base()
        root.addView(title("JAP"))
        val info=TextView(this).apply {
            text="Enter a number (0–9) for analysis"
            textSize=16f; setTextColor(Color.LTGRAY)
        }
        root.addView(info)
        val input=EditText(this).apply {
            hint="Number"; textSize=24f; gravity=Gravity.CENTER
            inputType=InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        root.addView(input,LinearLayout.LayoutParams(-1,72).apply{setMargins(0,20,0,12)})
        val analyze=Button(this).apply { text="ANALYZE" }
        root.addView(analyze,LinearLayout.LayoutParams(-1,62))
        val result=TextView(this).apply {
            textSize=17f; setTextColor(Color.WHITE); setPadding(16,24,16,24)
        }
        root.addView(result,LinearLayout.LayoutParams(-1,0,1f))
        val settings=Button(this).apply { text="SETTINGS" }
        root.addView(settings,LinearLayout.LayoutParams(-1,56))
        analyze.setOnClickListener {
            val n=input.text.toString().toIntOrNull()
            if(n==null || n !in 0..9) { result.text="Give me a number from 0 to 9."; return@setOnClickListener }
            result.text=analyzeNumber(n)
        }
        settings.setOnClickListener { showSettings() }
        setContentView(root)
    }

    private fun analyzeNumber(n:Int):String {
        val total=data.size
        val same=data.count{it.number==n}
        val type=if(n<=4) "S" else "B"
        val typeCount=data.count{it.type==type}
        val nextCounts=IntArray(10)
        for(i in 0 until data.lastIndex) {
            if(data[i].number==n) nextCounts[data[i+1].number]++
        }
        var best=0
        for(i in 1..9) if(nextCounts[i]>nextCounts[best]) best=i
        val transitions=data.count{it.number==n}
        val confidence=if(transitions>0) (nextCounts[best].toDouble()/transitions*100.0) else 0.0
        val shown=String.format("%.1f",confidence)
        return if(confidence>=70.0) {
            "MATCH: $shown%\n\nSuggested next number: $best\nType: ${if(best<=4)"S (Small)" else "B (Big)"}\n\nColor suggestion: ${if(best%2==0)"BLUE" else "RED"}\n\nHistorical matches for $n: $same / $total\n\nNote: This is a pattern/statistical estimate, not a guaranteed prediction."
        } else {
            "MATCH: $shown%\n\nGive Me Next Number\n\nHistorical matches for $n: $same / $total\n\nNot enough historical support for a 70%+ result."
        }
    }

    private fun showSettings() {
        val root=base()
        root.addView(title("SETTINGS"))
        val dataInfo=TextView(this).apply {
            text="DATA\n229 records loaded from the supplied 2-page dataset.\n\nS = 0–4\nB = 5–9"
            textSize=16f; setTextColor(Color.WHITE); setPadding(8,10,8,20)
        }
        root.addView(dataInfo)
        val add=Button(this).apply { text="DATA ADD / EDIT (coming next)" }
        root.addView(add)
        val gem=Button(this).apply { text="GEMINI AI API (optional)" }
        root.addView(gem)
        gem.setOnClickListener {
            Toast.makeText(this,"AI API integration can be connected in the next build. Keep API keys out of the APK source.",Toast.LENGTH_LONG).show()
        }
        val back=Button(this).apply { text="BACK" }
        root.addView(back)
        back.setOnClickListener { showHome() }
        setContentView(root)
    }
}
